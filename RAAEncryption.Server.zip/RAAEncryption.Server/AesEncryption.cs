﻿
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
namespace RAAEncryption.Server
{
      public class AesEncryption
    {
        private static readonly string secretKey = "1258777712345678";  // המפתח הסודי
        private static readonly string iv = "1234567890123456";  // IV (Initialization Vector)

        // פונקציה לההצפנה של טקסט
        public static string Encrypt(string plainText)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Encoding.UTF8.GetBytes(secretKey); // הגדרת המפתח
                aesAlg.IV = Encoding.UTF8.GetBytes(iv);  // הגדרת ה-IV

                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                    {
                        swEncrypt.Write(plainText);  // כותב את הטקסט המוצפן
                    }
                    return Convert.ToBase64String(msEncrypt.ToArray()); // מחזיר את הטקסט המוצפן כ-Base64
                }
            }
        }

        // פונקציה לפענוח של טקסט מוצפן
        public static string Decrypt(string cipherText)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Encoding.UTF8.GetBytes(secretKey); // המפתח הסודי
                aesAlg.IV = Encoding.UTF8.GetBytes(iv);  // ה-IV

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msDecrypt = new MemoryStream(Convert.FromBase64String(cipherText)))
                using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                {
                    return srDecrypt.ReadToEnd();  // מחזיר את הטקסט המפוענח
                }
            }
        }
    }
  

}
