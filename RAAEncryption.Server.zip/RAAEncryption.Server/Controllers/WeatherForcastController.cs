﻿using Microsoft.AspNetCore.Mvc;

namespace RAAEncryption.Server.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
    

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

       

        // API להצפנה
        [HttpPost("encrypt")]
        public IActionResult EncryptData([FromBody] EncryptRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.PlainText))
                {
                    return BadRequest("PlainText field is required.");
                }

                // הצפנה של הטקסט
                string encryptedText = AesEncryption.Encrypt(request.PlainText);
                return Ok(new { encryptedData = encryptedText });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // API לפענוח
        [HttpPost("decrypt")]
        public IActionResult DecryptData([FromBody] DecryptRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.PlainText))
                {
                    return BadRequest("PlainText field is required.");
                }

                //DO SONETHING WITH request.ClientIP FOR SECURITY REASONS

                // פענוח של הטקסט המוצפן
                string decryptedText = AesEncryption.Decrypt(request.PlainText);
                return Ok(new { decryptedData = decryptedText });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
    }

    public class EncryptRequest
    {
        public string PlainText { get; set; }
    }
    public class DecryptRequest
    {
        public string PlainText { get; set; }
        public string ClientIP { get; set; } 
    }
}
