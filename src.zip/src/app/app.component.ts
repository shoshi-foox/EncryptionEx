import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { IpService } from './services/ip.service'; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {

  DataToEncrypt: string = '';
  DecryptedData: string = '';
  EncryptedData: string = '';
  userIp: string= '';; 

  constructor(private http: HttpClient,private ipService: IpService) { }

  ngOnInit() {
    this.ipService.getUserIp().subscribe(response => {
      this.userIp = response.ip;  // שלוף את ה-IP מתוך התשובה
      console.log('User IP:', this.userIp);  // הצגת ה-IP בקונסול
    });
   }


  encryptData() {

    // שליחה לשרת של הנתון להצפנה
    const requestPayload = { PlainText: this.DataToEncrypt };

    this.http.post<{ encryptedData: string }>('/weatherforecast/encrypt', requestPayload, {
      headers: { 'Content-Type': 'application/json' }
    })
      .subscribe({
        next: (response) => this.EncryptedData = response.encryptedData,  // הצפנה שהתקבלה
        error: (err) => console.error('Error:', err)  // טיפול בשגיאות
      });


  }

  decryptData() {
    // שליחה לשרת של הנתון המוצפן
     const requestPayload = { PlainText: this.EncryptedData, ClientIP :this.userIp };
    this.http.post<{ decryptedData: string }>('/weatherforecast/decrypt', requestPayload)
      .subscribe(response => {
        // מקבלים את הנתון הפתוח מהשרת ומעדכנים את הממשק
        this.DecryptedData = response.decryptedData;
        console.log('הנתון המפוענח מהשרת:', this.DecryptedData);
      }, error => {
        console.error('שגיאה בפענוח הצפנה:', error);
      });
  }

  title = 'raaencryption.client';
}
