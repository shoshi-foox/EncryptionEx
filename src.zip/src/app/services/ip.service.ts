import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'  // מאפשר להזריק את השירות לכל רכיב בפרויקט
})
export class IpService {

  constructor(private http: HttpClient) { }

  // קריאה ל-API חיצוני שמחזיר את ה-IP של המשתמש
  getUserIp(): Observable<any> {
    return this.http.get<any>('https://api.ipify.org?format=json');
  }
}
